# Connect to another wifi
wlan.disconnect();
wlan.connect('Other Network', 'The Other Password')