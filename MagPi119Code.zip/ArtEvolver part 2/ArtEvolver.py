# ArtEvolver - by Sean McManus - www.sean.co.uk
import pygame, random, os
pygame.init()

win_width = 1024
win_height = 768
windowSurface = pygame.display.set_mode((win_width, win_height))
pygame.display.set_caption('ArtEvolver')
pygame.mouse.set_visible(False)

class Slide:
    def __init__(self, filename, opacity):
        self.filename = filename
        self.opacity = opacity

def index_images(path, images_list):
    for dir_or_file in os.listdir(path):
        path_plus_dir_or_file = os.path.join(path, dir_or_file)
        if os.path.isdir(path_plus_dir_or_file):
            index_images(path_plus_dir_or_file, images_list)
        elif dir_or_file.lower().endswith('.png') or dir_or_file.lower().endswith('.jpg'):
            images_list.append(path_plus_dir_or_file)
    return images_list

pictures = index_images("images_folder", [])

while True:
    sequence = pictures.copy()
    random.shuffle(sequence)

    # Set up initial list of current slides
    current_slide_list = []
    starting_opacities = [-90, -45, 45, 90, 135]
    for layer_opacity in starting_opacities:
        this_image = sequence.pop(0)
        this_slide = Slide(this_image, layer_opacity)
        current_slide_list.append(this_slide)

    while len(sequence) > 0:
        windowSurface.fill((0,0,0)) # Black
        for this_slide in current_slide_list:
            image_to_show = this_slide.filename
            new_opacity = this_slide.opacity + 1
            if new_opacity == 150:
                new_opacity = -150
            elif new_opacity == 0:
                this_slide.filename = sequence.pop(0) # replace image in this slide
            this_slide.opacity = new_opacity

            image_to_show = pygame.image.load(this_slide.filename)
            image_width = image_to_show.get_width()
            image_height = image_to_show.get_height()

            # Images are scaled for the long side (fit, not fill, the window)
            if image_height > image_width:
                scaling_factor = image_height / win_height
                new_width = int(image_width / scaling_factor)
                image_to_show  = pygame.transform.scale(image_to_show, (new_width, win_height))
            else:
                scaling_factor = image_width / win_width
                new_height = int(image_height / scaling_factor)
                image_to_show  = pygame.transform.scale(image_to_show, (win_width, new_height))

            # Remove # on next line if your screen is upside down
            #image_to_show = pygame.transform.flip(image_to_show, True, True)

            # get new height and width
            image_width = image_to_show.get_width()
            image_height = image_to_show.get_height()

            image_to_show.set_alpha(abs(new_opacity))
            windowSurface.blit(image_to_show,
                    (int(win_width/2) - int((0.5*image_width)),
                     int(win_height/2) - int((0.5*image_height))))
            
        pygame.display.update() # Shows composite after all slides have been blitted
        pygame.time.wait(30) # Adjust timings here if necessary

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONUP:
                pygame.quit()
