#ArtEvolver prototype - layers three images
import pygame
pygame.init()
windowSurface = pygame.display.set_mode((1024, 768))

images = ["images_folder/image1.jpg", "images_folder/image2.jpg",
          "images_folder/image3.jpg"]
opacities = [45, 90, 135]

windowSurface.fill((255,255,255))
for i in range(3):
    image_to_show = pygame.image.load(images[i])
    image_to_show.set_alpha(opacities[i])
    windowSurface.blit(image_to_show, (0, 0))
pygame.display.update()
